import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AUDIT, applyRound, complementEdge, equity, type Books, type Policy } from "@/lib/desk";

export const Route = createFileRoute("/")({ component: Home });

const START: Books = {
  operating: 100,
  locked: 0,
  reserve: 0,
  withdrawable: 0,
  reinvested: 0,
  realized: 0,
  peak: 100,
};

function money(n: number): string {
  const sign = n < 0 ? "−" : "";
  return `${sign}$${Math.abs(n).toFixed(2)}`;
}

function Home() {
  const [bidYes, setBidYes] = useState(0.48);
  const [bidNo, setBidNo] = useState(0.48);
  const [reinvest, setReinvest] = useState(60);
  const [withdraw, setWithdraw] = useState(25);
  const [maxDd, setMaxDd] = useState(20);
  const [rounds, setRounds] = useState<number[]>([-2, 4, 6, -1, 8]);
  const reserve = Math.max(0, 100 - reinvest - withdraw);
  const policy: Policy = { reinvest, withdraw, reserve };

  const edge = complementEdge(bidYes, bidNo);
  const crossed = bidYes + bidNo > 1;

  const ledger = useMemo(() => {
    let books = START;
    const rows: { pnl: number; reason: string; books: Books; halted: boolean }[] = [];
    for (const pnl of rounds) {
      const step = applyRound(books, pnl, policy, maxDd / 100);
      books = step.books;
      rows.push({ pnl, reason: step.reason, books, halted: step.halted });
    }
    return { books, rows };
  }, [rounds, policy.reinvest, policy.withdraw, policy.reserve, maxDd]);

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <header className="flex flex-col gap-4 border-b border-line pb-6 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="font-mono text-xs uppercase tracking-widest text-accent">Research console</p>
          <h1 className="mt-1 text-3xl font-medium tracking-tight">Arb Desk</h1>
          <p className="mt-2 max-w-xl text-sm text-muted">
            Same-market binary sports books. Live order submission stays off. This desk
            shows the structural edge test and how realized profit would be split — it is
            not a track record.
          </p>
        </div>
        <p className="w-fit rounded-md bg-danger px-3 py-2 text-sm font-medium text-bg">
          Not cleared for live capital
        </p>
      </header>

      <section className="mt-8 grid gap-4 lg:grid-cols-2">
        <article className="rounded-md border border-line bg-surface p-5">
          <h2 className="text-lg font-medium">Strategy gate</h2>
          <p className="mt-2 text-sm text-muted">
            If each ask is the complement of the other bid, an uncrossed book cannot
            offer a positive gross edge. A 5,000-sample sweep found zero positive
            uncrossed edges. A deliberately crossed pair (0.60 and 0.45) shows +$0.05.
          </p>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <label className="text-sm">
              <span className="text-muted">YES bid</span>
              <input
                className="mt-1 w-full rounded-md border border-line bg-surface-2 px-3 py-2 font-mono text-fg"
                type="number"
                min={0.01}
                max={0.99}
                step={0.01}
                value={bidYes}
                onChange={(e) => setBidYes(Number(e.target.value))}
              />
            </label>
            <label className="text-sm">
              <span className="text-muted">NO bid</span>
              <input
                className="mt-1 w-full rounded-md border border-line bg-surface-2 px-3 py-2 font-mono text-fg"
                type="number"
                min={0.01}
                max={0.99}
                step={0.01}
                value={bidNo}
                onChange={(e) => setBidNo(Number(e.target.value))}
              />
            </label>
          </div>
          <dl className="mt-4 grid grid-cols-2 gap-3 font-mono text-sm">
            <div>
              <dt className="text-muted">Gross edge</dt>
              <dd className={edge > 0 ? "text-accent" : "text-fg"}>{money(edge)} / share</dd>
            </div>
            <div>
              <dt className="text-muted">Book</dt>
              <dd>{crossed ? "Crossed — venue should already have matched" : "Uncrossed — edge is negative"}</dd>
            </div>
          </dl>
          <p className="mt-4 text-sm">
            Verdict: do not fund this strategy until recorded books show episodes that
            survive fees, skew under 250 ms, and latency of at least 2 seconds.
          </p>
        </article>

        <article className="rounded-md border border-line bg-surface p-5">
          <h2 className="text-lg font-medium">Profit split</h2>
          <p className="mt-2 text-sm text-muted">
            Only closed, realized profit is split. Losses hit operating capital first.
            Reinvestment stays in operating capital; it is not a second copy of the profit.
          </p>
          <label className="mt-4 block text-sm">
            <span className="flex justify-between text-muted">
              <span>Reinvest</span>
              <span className="font-mono text-fg">{reinvest}%</span>
            </span>
            <input
              className="mt-2 w-full accent-accent"
              type="range"
              min={0}
              max={100}
              value={reinvest}
              onChange={(e) => {
                const next = Number(e.target.value);
                setReinvest(next);
                if (next + withdraw > 100) setWithdraw(100 - next);
              }}
            />
          </label>
          <label className="mt-3 block text-sm">
            <span className="flex justify-between text-muted">
              <span>Withdrawable</span>
              <span className="font-mono text-fg">{withdraw}%</span>
            </span>
            <input
              className="mt-2 w-full accent-accent"
              type="range"
              min={0}
              max={100 - reinvest}
              value={withdraw}
              onChange={(e) => setWithdraw(Number(e.target.value))}
            />
          </label>
          <p className="mt-3 font-mono text-sm text-muted">Reserve takes the rest: {reserve}%</p>
          <label className="mt-3 block text-sm">
            <span className="flex justify-between text-muted">
              <span>Halt distributions after drawdown</span>
              <span className="font-mono text-fg">{maxDd}%</span>
            </span>
            <input
              className="mt-2 w-full accent-accent"
              type="range"
              min={5}
              max={50}
              value={maxDd}
              onChange={(e) => setMaxDd(Number(e.target.value))}
            />
          </label>
        </article>
      </section>

      <section className="mt-4 rounded-md border border-line bg-surface p-5">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <h2 className="text-lg font-medium">Worked ledger</h2>
          <p className="text-sm text-muted">Illustrative rounds, not trades. Edit a result to see the books move.</p>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {(
            [
              ["Operating", ledger.books.operating],
              ["Withdrawable", ledger.books.withdrawable],
              ["Reserve", ledger.books.reserve],
              ["Realized", ledger.books.realized],
            ] as const
          ).map(([label, value]) => (
            <div key={label} className="rounded-md bg-surface-2 px-3 py-3">
              <p className="text-xs uppercase tracking-wide text-muted">{label}</p>
              <p className="mt-1 font-mono text-xl">{money(value)}</p>
            </div>
          ))}
        </div>
        <p className="mt-3 font-mono text-sm text-muted">
          Equity {money(equity(ledger.books))} · reinvested to date {money(ledger.books.reinvested)} · peak{" "}
          {money(ledger.books.peak)}
        </p>
        <ul className="mt-4 divide-y divide-line">
          {ledger.rows.map((row, index) => (
            <li key={index} className="flex flex-wrap items-center gap-3 py-3 text-sm">
              <label className="font-mono">
                Round {index + 1}
                <input
                  className="ml-2 w-24 rounded-md border border-line bg-bg px-2 py-2 text-fg"
                  type="number"
                  step={0.5}
                  value={rounds[index]}
                  onChange={(e) => {
                    const copy = rounds.slice();
                    copy[index] = Number(e.target.value);
                    setRounds(copy);
                  }}
                />
              </label>
              <span className={row.halted ? "text-danger" : "text-ok"}>{row.reason}</span>
              <span className="ml-auto font-mono text-muted">operating {money(row.books.operating)}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-4 rounded-md border border-line bg-surface p-5">
        <h2 className="text-lg font-medium">Audit, as implemented</h2>
        <ol className="mt-4 space-y-3">
          {AUDIT.map((item) => (
            <li key={item.id} className="grid gap-1 border-t border-line pt-3 sm:grid-cols-[8rem_1fr]">
              <p className="font-mono text-xs text-accent">
                {String(item.id).padStart(2, "0")} · {item.item}
              </p>
              <p className="text-sm text-muted">{item.status}</p>
            </li>
          ))}
        </ol>
      </section>
    </main>
  );
}
