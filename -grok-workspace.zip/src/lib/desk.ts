/** Same rules as sports_arb.capital and strategy_gate. Money is integer cents. */

export type Books = {
  operating: number;
  locked: number;
  reserve: number;
  withdrawable: number;
  reinvested: number;
  realized: number;
  peak: number;
};

export type Policy = { reinvest: number; withdraw: number; reserve: number };

export function complementEdge(bidYes: number, bidNo: number): number {
  const askYes = 1 - bidNo;
  const askNo = 1 - bidYes;
  return 1 - askYes - askNo;
}

export function equity(b: Books): number {
  return b.operating + b.locked + b.reserve + b.withdrawable;
}

export function applyRound(
  books: Books,
  realized: number,
  policy: Policy,
  maxDrawdown: number,
): { books: Books; halted: boolean; reason: string; slices: Policy & { eligible: number } } {
  const sum = policy.reinvest + policy.withdraw + policy.reserve;
  if (Math.abs(sum - 100) > 0.01) {
    return {
      books,
      halted: true,
      reason: "policy must sum to 100",
      slices: { ...policy, eligible: 0 },
    };
  }
  const operating = books.operating + realized;
  const next: Books = {
    ...books,
    operating,
    realized: books.realized + realized,
  };
  const eq = equity(next);
  const peak = Math.max(books.peak, eq);
  const dd = peak > 0 && eq < books.peak ? (books.peak - eq) / books.peak : 0;

  if (realized <= 0) {
    return {
      books: { ...next, peak },
      halted: dd > maxDrawdown,
      reason: "loss — nothing distributed",
      slices: { reinvest: 0, withdraw: 0, reserve: 0, eligible: 0 },
    };
  }
  if (dd > maxDrawdown) {
    return {
      books: { ...next, peak: Math.max(books.peak, equity(next)) },
      halted: true,
      reason: "drawdown halt — profit stays in operating capital",
      slices: { reinvest: 0, withdraw: 0, reserve: 0, eligible: realized },
    };
  }
  const reinvest = (realized * policy.reinvest) / 100;
  const reserve = (realized * policy.reserve) / 100;
  const withdraw = realized - reinvest - reserve;
  const done: Books = {
    operating: operating - withdraw - reserve,
    locked: books.locked,
    reserve: books.reserve + reserve,
    withdrawable: books.withdrawable + withdraw,
    reinvested: books.reinvested + reinvest,
    realized: books.realized + realized,
    peak: 0,
  };
  done.peak = Math.max(books.peak, equity(done));
  return {
    books: done,
    halted: false,
    reason: "allocated",
    slices: { reinvest, withdraw, reserve, eligible: realized },
  };
}

export const AUDIT: { id: number; item: string; status: string }[] = [
  { id: 1, item: "Python 3.13 pin", status: "Fixed in project metadata. This preview host is 3.10, so the Kalshi SDK is not installed here." },
  { id: 2, item: "Raw recorder", status: "Polymarket recorder added. Kalshi still needs credentials in the current gateway — public client not verified." },
  { id: 3, item: "Replay clock", status: "Replay passes snapshot time into the detector. Live ledger still uses wall clock for real trading days." },
  { id: 4, item: "Strategy gate", status: "Verified: 5,000 uncrossed complement books, zero positive gross edges. Crossed example +$0.05." },
  { id: 5, item: "Fill simulator", status: "FOK/FAK replay with latency. Not a full historical engine — no recorded books in this workspace." },
  { id: 6, item: "Pair skew", status: "Replay can sweep max pair skew. Kalshi books still share one receive time." },
  { id: 7, item: "Survivorship", status: "Recorder stores each discovery universe. Ranking by today's volume is still how discovery works." },
  { id: 8, item: "Historical fees", status: "Universe rows include the fee schedule as of discovery. No multi-year archive yet." },
  { id: 9, item: "Latency", status: "Replay accepts 0/1/2/5s. No measured round trip from a colocated host." },
  { id: 10, item: "One parameter set", status: "Live traders read slippage and min shares from LiveRiskConfig instead of hard-coded values." },
  { id: 11, item: "PnL and lock-up", status: "Capital module refuses to distribute unrealized or locked funds. Merge/redeem is not implemented." },
  { id: 12, item: "Pre-game vs in-play", status: "Not separated in the live scanner. Kalshi start time is still an expiration field." },
  { id: 13, item: "Share precision", status: "Not quantized at signing. Still a live-path defect." },
  { id: 14, item: "Kalshi websocket", status: "Queue.put replaced with put_nowait." },
  { id: 15, item: "Env template", status: "Live arming lines are commented out." },
  { id: 16, item: "Stable data paths", status: "Kill switch, lock and ledger resolve from SPORTS_ARB_DATA or the repo data directory." },
  { id: 17, item: "Minor defects", status: "Partially open: Windows lock, NO_FILL capital release, unknown market classification." },
  { id: 18, item: "Execution tests", status: "Fill-model tests pass. LiveTrader state machine is still untested without a fake gateway." },
  { id: 19, item: "CI, license, config", status: "LICENSE, GitHub Actions workflow, and config/strategy.toml added. No lockfile until a 3.13 install." },
  { id: 20, item: "Data quality", status: "Crossed books, bad prices, and timestamp order are counted. Analytics dashboard is this console, not venue PnL." },
];
