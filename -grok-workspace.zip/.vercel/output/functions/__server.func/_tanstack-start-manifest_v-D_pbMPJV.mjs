//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D_pbMPJV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BUdPIPb_.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BUdPIPb_.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DNcKqUYp.js"]
	}
} });
//#endregion
export { tsrStartManifest };
