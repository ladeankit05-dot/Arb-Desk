import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DFNeihd-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function complementEdge(bidYes, bidNo) {
	const askYes = 1 - bidNo;
	const askNo = 1 - bidYes;
	return 1 - askYes - askNo;
}
function equity(b) {
	return b.operating + b.locked + b.reserve + b.withdrawable;
}
function applyRound(books, realized, policy, maxDrawdown) {
	const sum = policy.reinvest + policy.withdraw + policy.reserve;
	if (Math.abs(sum - 100) > .01) return {
		books,
		halted: true,
		reason: "policy must sum to 100",
		slices: {
			...policy,
			eligible: 0
		}
	};
	const operating = books.operating + realized;
	const next = {
		...books,
		operating,
		realized: books.realized + realized
	};
	const eq = equity(next);
	const peak = Math.max(books.peak, eq);
	const dd = peak > 0 && eq < books.peak ? (books.peak - eq) / books.peak : 0;
	if (realized <= 0) return {
		books: {
			...next,
			peak
		},
		halted: dd > maxDrawdown,
		reason: "loss — nothing distributed",
		slices: {
			reinvest: 0,
			withdraw: 0,
			reserve: 0,
			eligible: 0
		}
	};
	if (dd > maxDrawdown) return {
		books: {
			...next,
			peak: Math.max(books.peak, equity(next))
		},
		halted: true,
		reason: "drawdown halt — profit stays in operating capital",
		slices: {
			reinvest: 0,
			withdraw: 0,
			reserve: 0,
			eligible: realized
		}
	};
	const reinvest = realized * policy.reinvest / 100;
	const reserve = realized * policy.reserve / 100;
	const withdraw = realized - reinvest - reserve;
	const done = {
		operating: operating - withdraw - reserve,
		locked: books.locked,
		reserve: books.reserve + reserve,
		withdrawable: books.withdrawable + withdraw,
		reinvested: books.reinvested + reinvest,
		realized: books.realized + realized,
		peak: 0
	};
	done.peak = Math.max(books.peak, equity(done));
	return {
		books: done,
		halted: false,
		reason: "allocated",
		slices: {
			reinvest,
			withdraw,
			reserve,
			eligible: realized
		}
	};
}
var AUDIT = [
	{
		id: 1,
		item: "Python 3.13 pin",
		status: "Fixed in project metadata. This preview host is 3.10, so the Kalshi SDK is not installed here."
	},
	{
		id: 2,
		item: "Raw recorder",
		status: "Polymarket recorder added. Kalshi still needs credentials in the current gateway — public client not verified."
	},
	{
		id: 3,
		item: "Replay clock",
		status: "Replay passes snapshot time into the detector. Live ledger still uses wall clock for real trading days."
	},
	{
		id: 4,
		item: "Strategy gate",
		status: "Verified: 5,000 uncrossed complement books, zero positive gross edges. Crossed example +$0.05."
	},
	{
		id: 5,
		item: "Fill simulator",
		status: "FOK/FAK replay with latency. Not a full historical engine — no recorded books in this workspace."
	},
	{
		id: 6,
		item: "Pair skew",
		status: "Replay can sweep max pair skew. Kalshi books still share one receive time."
	},
	{
		id: 7,
		item: "Survivorship",
		status: "Recorder stores each discovery universe. Ranking by today's volume is still how discovery works."
	},
	{
		id: 8,
		item: "Historical fees",
		status: "Universe rows include the fee schedule as of discovery. No multi-year archive yet."
	},
	{
		id: 9,
		item: "Latency",
		status: "Replay accepts 0/1/2/5s. No measured round trip from a colocated host."
	},
	{
		id: 10,
		item: "One parameter set",
		status: "Live traders read slippage and min shares from LiveRiskConfig instead of hard-coded values."
	},
	{
		id: 11,
		item: "PnL and lock-up",
		status: "Capital module refuses to distribute unrealized or locked funds. Merge/redeem is not implemented."
	},
	{
		id: 12,
		item: "Pre-game vs in-play",
		status: "Not separated in the live scanner. Kalshi start time is still an expiration field."
	},
	{
		id: 13,
		item: "Share precision",
		status: "Not quantized at signing. Still a live-path defect."
	},
	{
		id: 14,
		item: "Kalshi websocket",
		status: "Queue.put replaced with put_nowait."
	},
	{
		id: 15,
		item: "Env template",
		status: "Live arming lines are commented out."
	},
	{
		id: 16,
		item: "Stable data paths",
		status: "Kill switch, lock and ledger resolve from SPORTS_ARB_DATA or the repo data directory."
	},
	{
		id: 17,
		item: "Minor defects",
		status: "Partially open: Windows lock, NO_FILL capital release, unknown market classification."
	},
	{
		id: 18,
		item: "Execution tests",
		status: "Fill-model tests pass. LiveTrader state machine is still untested without a fake gateway."
	},
	{
		id: 19,
		item: "CI, license, config",
		status: "LICENSE, GitHub Actions workflow, and config/strategy.toml added. No lockfile until a 3.13 install."
	},
	{
		id: 20,
		item: "Data quality",
		status: "Crossed books, bad prices, and timestamp order are counted. Analytics dashboard is this console, not venue PnL."
	}
];
var START = {
	operating: 100,
	locked: 0,
	reserve: 0,
	withdrawable: 0,
	reinvested: 0,
	realized: 0,
	peak: 100
};
function money(n) {
	return `${n < 0 ? "−" : ""}$${Math.abs(n).toFixed(2)}`;
}
function Home() {
	const [bidYes, setBidYes] = (0, import_react.useState)(.48);
	const [bidNo, setBidNo] = (0, import_react.useState)(.48);
	const [reinvest, setReinvest] = (0, import_react.useState)(60);
	const [withdraw, setWithdraw] = (0, import_react.useState)(25);
	const [maxDd, setMaxDd] = (0, import_react.useState)(20);
	const [rounds, setRounds] = (0, import_react.useState)([
		-2,
		4,
		6,
		-1,
		8
	]);
	const reserve = Math.max(0, 100 - reinvest - withdraw);
	const policy = {
		reinvest,
		withdraw,
		reserve
	};
	const edge = complementEdge(bidYes, bidNo);
	const crossed = bidYes + bidNo > 1;
	const ledger = (0, import_react.useMemo)(() => {
		let books = START;
		const rows = [];
		for (const pnl of rounds) {
			const step = applyRound(books, pnl, policy, maxDd / 100);
			books = step.books;
			rows.push({
				pnl,
				reason: step.reason,
				books,
				halted: step.halted
			});
		}
		return {
			books,
			rows
		};
	}, [
		rounds,
		policy.reinvest,
		policy.withdraw,
		policy.reserve,
		maxDd
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-8 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-4 border-b border-line pb-6 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs uppercase tracking-widest text-accent",
						children: "Research console"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-3xl font-medium tracking-tight",
						children: "Arb Desk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-sm text-muted",
						children: "Same-market binary sports books. Live order submission stays off. This desk shows the structural edge test and how realized profit would be split — it is not a track record."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "w-fit rounded-md bg-danger px-3 py-2 text-sm font-medium text-bg",
					children: "Not cleared for live capital"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-md border border-line bg-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-medium",
							children: "Strategy gate"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "If each ask is the complement of the other bid, an uncrossed book cannot offer a positive gross edge. A 5,000-sample sweep found zero positive uncrossed edges. A deliberately crossed pair (0.60 and 0.45) shows +$0.05."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: "YES bid"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "mt-1 w-full rounded-md border border-line bg-surface-2 px-3 py-2 font-mono text-fg",
									type: "number",
									min: .01,
									max: .99,
									step: .01,
									value: bidYes,
									onChange: (e) => setBidYes(Number(e.target.value))
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: "NO bid"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "mt-1 w-full rounded-md border border-line bg-surface-2 px-3 py-2 font-mono text-fg",
									type: "number",
									min: .01,
									max: .99,
									step: .01,
									value: bidNo,
									onChange: (e) => setBidNo(Number(e.target.value))
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 grid grid-cols-2 gap-3 font-mono text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Gross edge"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: edge > 0 ? "text-accent" : "text-fg",
								children: [money(edge), " / share"]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Book"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: crossed ? "Crossed — venue should already have matched" : "Uncrossed — edge is negative" })] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm",
							children: "Verdict: do not fund this strategy until recorded books show episodes that survive fees, skew under 250 ms, and latency of at least 2 seconds."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-md border border-line bg-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-medium",
							children: "Profit split"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Only closed, realized profit is split. Losses hit operating capital first. Reinvestment stays in operating capital; it is not a second copy of the profit."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-4 block text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex justify-between text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Reinvest" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono text-fg",
									children: [reinvest, "%"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "mt-2 w-full accent-accent",
								type: "range",
								min: 0,
								max: 100,
								value: reinvest,
								onChange: (e) => {
									const next = Number(e.target.value);
									setReinvest(next);
									if (next + withdraw > 100) setWithdraw(100 - next);
								}
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-3 block text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex justify-between text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Withdrawable" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono text-fg",
									children: [withdraw, "%"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "mt-2 w-full accent-accent",
								type: "range",
								min: 0,
								max: 100 - reinvest,
								value: withdraw,
								onChange: (e) => setWithdraw(Number(e.target.value))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 font-mono text-sm text-muted",
							children: [
								"Reserve takes the rest: ",
								reserve,
								"%"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-3 block text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex justify-between text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Halt distributions after drawdown" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono text-fg",
									children: [maxDd, "%"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "mt-2 w-full accent-accent",
								type: "range",
								min: 5,
								max: 50,
								value: maxDd,
								onChange: (e) => setMaxDd(Number(e.target.value))
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-4 rounded-md border border-line bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-medium",
							children: "Worked ledger"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Illustrative rounds, not trades. Edit a result to see the books move."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4",
						children: [
							["Operating", ledger.books.operating],
							["Withdrawable", ledger.books.withdrawable],
							["Reserve", ledger.books.reserve],
							["Realized", ledger.books.realized]
						].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md bg-surface-2 px-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-wide text-muted",
								children: label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-mono text-xl",
								children: money(value)
							})]
						}, label))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 font-mono text-sm text-muted",
						children: [
							"Equity ",
							money(equity(ledger.books)),
							" · reinvested to date ",
							money(ledger.books.reinvested),
							" · peak",
							" ",
							money(ledger.books.peak)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 divide-y divide-line",
						children: ledger.rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-wrap items-center gap-3 py-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "font-mono",
									children: [
										"Round ",
										index + 1,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											className: "ml-2 w-24 rounded-md border border-line bg-bg px-2 py-2 text-fg",
											type: "number",
											step: .5,
											value: rounds[index],
											onChange: (e) => {
												const copy = rounds.slice();
												copy[index] = Number(e.target.value);
												setRounds(copy);
											}
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: row.halted ? "text-danger" : "text-ok",
									children: row.reason
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ml-auto font-mono text-muted",
									children: ["operating ", money(row.books.operating)]
								})
							]
						}, index))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-4 rounded-md border border-line bg-surface p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-medium",
					children: "Audit, as implemented"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-4 space-y-3",
					children: AUDIT.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid gap-1 border-t border-line pt-3 sm:grid-cols-[8rem_1fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs text-accent",
							children: [
								String(item.id).padStart(2, "0"),
								" · ",
								item.item
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: item.status
						})]
					}, item.id))
				})]
			})
		]
	});
}
//#endregion
export { Home as component };
